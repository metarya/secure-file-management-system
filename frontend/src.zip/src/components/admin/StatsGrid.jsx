import { Grid } from "@mui/material";
import DashboardCard from "./DashboardCard";

export default function StatsGrid({ stats }) {
  const cards = [
    {
      title: "Total Users",
      value: stats?.totalUsers ?? 0,
    },
    {
      title: "Admin Users",
      value: stats?.totalAdmins ?? 0,
    },
    {
      title: "Regular Users",
      value: stats?.totalRegularUsers ?? 0,
    },
  ];

  return (
    <Grid container spacing={3}>
      {cards.map((card) => (
        <Grid
          item
          xs={12}
          md={4}
          key={card.title}
        >
          <DashboardCard
            title={card.title}
            value={card.value}
          />
        </Grid>
      ))}
    </Grid>
  );
}