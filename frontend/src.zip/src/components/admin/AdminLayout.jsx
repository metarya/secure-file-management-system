import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Box,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  IconButton,
  Avatar,
  Tooltip,
} from "@mui/material";
import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import PeopleRoundedIcon from "@mui/icons-material/PeopleRounded";
import FolderRoundedIcon from "@mui/icons-material/FolderRounded";
import AssessmentRoundedIcon from "@mui/icons-material/AssessmentRounded";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import ShieldRoundedIcon from "@mui/icons-material/ShieldRounded";
import ChevronLeftRoundedIcon from "@mui/icons-material/ChevronLeftRounded";
import { loadStoredUser, logout as doLogout } from "../../utils/Auth";

const SIDEBAR_W = 240;
const SIDEBAR_COLLAPSED = 68;

const NAV_ITEMS = [
  { label: "Dashboard",       path: "/admin/dashboard", icon: <DashboardRoundedIcon /> },
  { label: "Users",           path: "/admin/users",     icon: <PeopleRoundedIcon /> },
  { label: "Files",           path: "/admin/files",     icon: <FolderRoundedIcon />, disabled: true },
  { label: "Analytics",       path: "/admin/analytics", icon: <AssessmentRoundedIcon />, disabled: true },
];

export default function AdminLayout({ children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const user = loadStoredUser();

  function logout() {
    doLogout();
    navigate("/login", { replace: true });
  }

  const sidebarWidth = collapsed ? SIDEBAR_COLLAPSED : SIDEBAR_W;

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", background: "#f0f2f8" }}>
      {/* ── Sidebar ── */}
      <Drawer
        variant="permanent"
        sx={{
          width: sidebarWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: sidebarWidth,
            boxSizing: "border-box",
            background: "linear-gradient(180deg, #0f172a 0%, #1e293b 100%)",
            border: "none",
            boxShadow: "4px 0 24px rgba(0,0,0,0.18)",
            transition: "width 0.22s cubic-bezier(0.4,0,0.2,1)",
            overflowX: "hidden",
          },
        }}
      >
        {/* Brand */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            px: collapsed ? 1.5 : 2.5,
            py: 2.5,
            minHeight: 72,
            borderBottom: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <Box
            sx={{
              width: 36,
              height: 36,
              borderRadius: "10px",
              background: "linear-gradient(135deg, #6366f1 0%, #3b82f6 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <ShieldRoundedIcon sx={{ color: "#fff", fontSize: 20 }} />
          </Box>
          {!collapsed && (
            <Box>
              <Typography sx={{ color: "#fff", fontWeight: 700, fontSize: "0.95rem", lineHeight: 1.2 }}>
                SFMS Admin
              </Typography>
              <Typography sx={{ color: "rgba(255,255,255,0.4)", fontSize: "0.72rem" }}>
                Control Panel
              </Typography>
            </Box>
          )}
          <IconButton
            onClick={() => setCollapsed(c => !c)}
            sx={{ ml: "auto", color: "rgba(255,255,255,0.4)", p: 0.5, flexShrink: 0,
              "&:hover": { color: "#fff" } }}
            size="small"
          >
            {collapsed ? <MenuRoundedIcon fontSize="small" /> : <ChevronLeftRoundedIcon fontSize="small" />}
          </IconButton>
        </Box>

        {/* Nav */}
        <List sx={{ px: 1, pt: 1.5, flexGrow: 1 }}>
          {NAV_ITEMS.map(item => {
            const active = location.pathname === item.path;
            return (
              <Tooltip key={item.path} title={collapsed ? item.label : ""} placement="right">
                <ListItem disablePadding sx={{ mb: 0.5 }}>
                  <ListItemButton
                    onClick={() => !item.disabled && navigate(item.path)}
                    disabled={item.disabled}
                    sx={{
                      borderRadius: "10px",
                      px: collapsed ? 1.5 : 2,
                      py: 1.1,
                      minHeight: 44,
                      background: active
                        ? "linear-gradient(90deg, rgba(99,102,241,0.25) 0%, rgba(59,130,246,0.15) 100%)"
                        : "transparent",
                      borderLeft: active ? "3px solid #6366f1" : "3px solid transparent",
                      "&:hover": {
                        background: active
                          ? "linear-gradient(90deg, rgba(99,102,241,0.3) 0%, rgba(59,130,246,0.2) 100%)"
                          : "rgba(255,255,255,0.06)",
                      },
                      "&.Mui-disabled": { opacity: 0.35 },
                      transition: "all 0.15s ease",
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: collapsed ? 0 : 36,
                        color: active ? "#818cf8" : "rgba(255,255,255,0.5)",
                        mr: collapsed ? 0 : 0,
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                    {!collapsed && (
                      <ListItemText
                        primary={item.label}
                        primaryTypographyProps={{
                          fontSize: "0.875rem",
                          fontWeight: active ? 600 : 400,
                          color: active ? "#e0e7ff" : "rgba(255,255,255,0.6)",
                        }}
                      />
                    )}
                    {!collapsed && item.disabled && (
                      <Typography sx={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.25)",
                        background: "rgba(255,255,255,0.08)", px: 0.8, py: 0.2, borderRadius: "4px" }}>
                        Soon
                      </Typography>
                    )}
                  </ListItemButton>
                </ListItem>
              </Tooltip>
            );
          })}
        </List>

        {/* User + logout */}
        <Box sx={{ borderTop: "1px solid rgba(255,255,255,0.07)", p: 1.5 }}>
          {!collapsed && (
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, px: 1, py: 1, mb: 0.5 }}>
              <Avatar
                sx={{ width: 32, height: 32, fontSize: "0.8rem",
                  background: "linear-gradient(135deg, #6366f1 0%, #3b82f6 100%)" }}
              >
                {user?.fullName?.[0] ?? user?.email?.[0] ?? "A"}
              </Avatar>
              <Box sx={{ overflow: "hidden" }}>
                <Typography sx={{ color: "#fff", fontSize: "0.8rem", fontWeight: 600,
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {user?.fullName ?? "Admin"}
                </Typography>
                <Typography sx={{ color: "rgba(255,255,255,0.35)", fontSize: "0.68rem",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {user?.email ?? ""}
                </Typography>
              </Box>
            </Box>
          )}
          <Tooltip title={collapsed ? "Logout" : ""} placement="right">
            <ListItemButton
              onClick={logout}
              sx={{
                borderRadius: "10px",
                px: collapsed ? 1.5 : 2,
                py: 1,
                "&:hover": { background: "rgba(239,68,68,0.15)" },
              }}
            >
              <ListItemIcon sx={{ minWidth: collapsed ? 0 : 36, color: "rgba(239,68,68,0.7)" }}>
                <LogoutRoundedIcon fontSize="small" />
              </ListItemIcon>
              {!collapsed && (
                <ListItemText
                  primary="Logout"
                  primaryTypographyProps={{ fontSize: "0.875rem", color: "rgba(239,68,68,0.8)" }}
                />
              )}
            </ListItemButton>
          </Tooltip>
        </Box>
      </Drawer>

      {/* ── Page content ── */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          minWidth: 0,
          display: "flex",
          flexDirection: "column",
          transition: "margin 0.22s cubic-bezier(0.4,0,0.2,1)",
        }}
      >
        {children}
      </Box>
    </Box>
  );
}
