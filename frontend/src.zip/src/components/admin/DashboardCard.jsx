import { Paper, Typography } from "@mui/material";

export default function DashboardCard({
  title,
  value,
}) {
  return (
    <Paper
      elevation={3}
      sx={{
        p: 3,
        borderRadius: 3,
        height: "100%",
      }}
    >
      <Typography
        variant="body2"
        color="text.secondary"
      >
        {title}
      </Typography>

      <Typography
        variant="h4"
        fontWeight={700}
        mt={1}
      >
        {value}
      </Typography>
    </Paper>
  );
}