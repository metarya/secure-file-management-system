import { useEffect, useState, useCallback } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, IconButton,
  TextField, InputAdornment, CircularProgress, Avatar,
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Select, MenuItem, FormControl, InputLabel,
  Tooltip, Alert, Snackbar, TablePagination, Skeleton,
} from "@mui/material";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import EditRoundedIcon from "@mui/icons-material/EditRounded";
import BlockRoundedIcon from "@mui/icons-material/BlockRounded";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import PeopleRoundedIcon from "@mui/icons-material/PeopleRounded";
import AdminLayout from "../../components/admin/AdminLayout";
import { getAllUsers, updateUserRole, updateUserStatus } from "../../services/adminService";

function initials(name, email) {
  if (name) return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  if (email) return email[0].toUpperCase();
  return "?";
}

function avatarColor(str = "") {
  const palette = [
    "linear-gradient(135deg,#6366f1,#3b82f6)",
    "linear-gradient(135deg,#f59e0b,#ef4444)",
    "linear-gradient(135deg,#10b981,#06b6d4)",
    "linear-gradient(135deg,#8b5cf6,#ec4899)",
    "linear-gradient(135deg,#f97316,#eab308)",
  ];
  let h = 0;
  for (let i = 0; i < str.length; i++) h = str.charCodeAt(i) + ((h << 5) - h);
  return palette[Math.abs(h) % palette.length];
}

function RoleChip({ role }) {
  const styles = {
    ADMIN: { label: "Admin", color: "#f59e0b", bg: "rgba(245,158,11,0.1)", border: "rgba(245,158,11,0.25)" },
    USER:  { label: "User",  color: "#6366f1", bg: "rgba(99,102,241,0.1)", border: "rgba(99,102,241,0.25)" },
  };
  const s = styles[role] ?? styles.USER;
  return (
    <Chip label={s.label} size="small" sx={{
      color: s.color, background: s.bg, border: `1px solid ${s.border}`,
      fontWeight: 700, fontSize: "0.72rem", height: 24,
    }} />
  );
}

function StatusChip({ status }) {
  const isActive = status !== "BLOCKED";
  return (
    <Chip
      icon={isActive
        ? <CheckCircleRoundedIcon sx={{ fontSize: "12px !important" }} />
        : <BlockRoundedIcon sx={{ fontSize: "12px !important" }} />}
      label={isActive ? "Active" : "Blocked"}
      size="small"
      sx={{
        color: isActive ? "#22c55e" : "#ef4444",
        background: isActive ? "rgba(34,197,94,0.1)" : "rgba(239,68,68,0.1)",
        border: `1px solid ${isActive ? "rgba(34,197,94,0.25)" : "rgba(239,68,68,0.25)"}`,
        fontWeight: 700, fontSize: "0.72rem", height: 24,
        "& .MuiChip-icon": { color: "inherit", ml: "6px" },
      }}
    />
  );
}

function EditRoleDialog({ open, user, onClose, onConfirm, saving }) {
  const [role, setRole] = useState(user?.role ?? "USER");
  useEffect(() => { if (user) setRole(user.role ?? "USER"); }, [user]);
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth
      PaperProps={{ sx: { borderRadius: "16px", p: 0.5 } }}>
      <DialogTitle sx={{ fontWeight: 700, fontSize: "1.05rem", pb: 1 }}>Change Role</DialogTitle>
      <DialogContent>
        <Typography sx={{ fontSize: "0.875rem", color: "#64748b", mb: 2.5 }}>
          Updating role for <strong>{user?.fullName ?? user?.email}</strong>
        </Typography>
        <FormControl fullWidth size="small">
          <InputLabel>Role</InputLabel>
          <Select value={role} label="Role" onChange={e => setRole(e.target.value)}
            sx={{ borderRadius: "10px" }}>
            <MenuItem value="USER">User</MenuItem>
            <MenuItem value="ADMIN">Admin</MenuItem>
          </Select>
        </FormControl>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
        <Button onClick={onClose} sx={{ borderRadius: "10px", textTransform: "none", color: "#64748b" }}>Cancel</Button>
        <Button variant="contained" onClick={() => onConfirm(role)} disabled={saving}
          sx={{ borderRadius: "10px", textTransform: "none", fontWeight: 600,
            background: "linear-gradient(135deg,#6366f1,#3b82f6)",
            "&:hover": { background: "linear-gradient(135deg,#4f46e5,#2563eb)" } }}>
          {saving ? <CircularProgress size={16} sx={{ color: "#fff" }} /> : "Save"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function ToggleStatusDialog({ open, user, onClose, onConfirm, saving }) {
  const isActive = user?.status !== "BLOCKED";
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth
      PaperProps={{ sx: { borderRadius: "16px", p: 0.5 } }}>
      <DialogTitle sx={{ fontWeight: 700, fontSize: "1.05rem", pb: 1 }}>
        {isActive ? "Block User" : "Unblock User"}
      </DialogTitle>
      <DialogContent>
        <Typography sx={{ fontSize: "0.875rem", color: "#64748b" }}>
          {isActive
            ? <><strong>{user?.fullName ?? user?.email}</strong> will lose access immediately.</>
            : <>Restore access for <strong>{user?.fullName ?? user?.email}</strong>?</>}
        </Typography>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
        <Button onClick={onClose} sx={{ borderRadius: "10px", textTransform: "none", color: "#64748b" }}>Cancel</Button>
        <Button variant="contained" onClick={onConfirm} disabled={saving}
          sx={{
            borderRadius: "10px", textTransform: "none", fontWeight: 600,
            background: isActive ? "linear-gradient(135deg,#ef4444,#dc2626)" : "linear-gradient(135deg,#22c55e,#16a34a)",
          }}>
          {saving ? <CircularProgress size={16} sx={{ color: "#fff" }} /> : isActive ? "Block" : "Unblock"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function TableRowSkeleton() {
  return (
    <TableRow>
      {[44, 180, 150, 70, 70, 60].map((w, i) => (
        <TableCell key={i}><Skeleton width={w} height={20} sx={{ borderRadius: 4 }} /></TableCell>
      ))}
    </TableRow>
  );
}

export default function UserManagementPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [roleDialog, setRoleDialog] = useState({ open: false, user: null });
  const [statusDialog, setStatusDialog] = useState({ open: false, user: null });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState({ open: false, message: "", severity: "success" });

  const showToast = (message, severity = "success") => setToast({ open: true, message, severity });

  const fetchUsers = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const data = await getAllUsers();
      setUsers(Array.isArray(data) ? data : []);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const filtered = users.filter(u => {
    const q = search.toLowerCase();
    return !q || (u.fullName ?? "").toLowerCase().includes(q) ||
      (u.email ?? "").toLowerCase().includes(q) || (u.role ?? "").toLowerCase().includes(q);
  });
  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  async function handleRoleConfirm(newRole) {
    setSaving(true);
    try {
      await updateUserRole(roleDialog.user.userId, newRole);
      setUsers(prev => prev.map(u => u.userId === roleDialog.user.userId ? { ...u, role: newRole } : u));
      showToast(`Role updated to ${newRole}`);
      setRoleDialog({ open: false, user: null });
    } catch (e) { showToast(e.message, "error"); }
    finally { setSaving(false); }
  }

  async function handleStatusConfirm() {
    const u = statusDialog.user;
    const newStatus = u.status === "ACTIVE" ? "BLOCKED" : "ACTIVE";
    setSaving(true);
    try {
      await updateUserStatus(u.userId, newStatus);
      setUsers(prev => prev.map(x => x.userId === u.userId ? { ...x, status: newStatus } : x));
      showToast(`User ${newStatus === "BLOCKED" ? "blocked" : "unblocked"}`);
      setStatusDialog({ open: false, user: null });
    } catch (e) { showToast(e.message, "error"); }
    finally { setSaving(false); }
  }

  const COL_SX = {
    fontWeight: 700, fontSize: "0.72rem", color: "#94a3b8",
    textTransform: "uppercase", letterSpacing: "0.06em",
    py: 1.5, borderBottom: "1px solid #f1f5f9",
  };

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 3, md: 5 }, maxWidth: 1200, width: "100%" }}>

        {/* Header */}
        <Box sx={{ mb: 4, display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 2 }}>
          <Box>
            <Typography sx={{ fontSize: "0.8rem", fontWeight: 600, color: "#6366f1",
              textTransform: "uppercase", letterSpacing: "0.08em", mb: 0.5 }}>
              Administration
            </Typography>
            <Typography sx={{ fontSize: "1.8rem", fontWeight: 800, color: "#0f172a", lineHeight: 1.2 }}>
              User Management
            </Typography>
            <Typography sx={{ fontSize: "0.875rem", color: "#94a3b8", mt: 0.5 }}>
              {loading ? "Loading…" : `${users.length} total users`}
            </Typography>
          </Box>
          <Tooltip title="Refresh">
            <IconButton onClick={fetchUsers} disabled={loading}
              sx={{ border: "1px solid #e2e8f0", borderRadius: "10px", p: 1,
                "&:hover": { background: "#f8fafc", borderColor: "#6366f1" } }}>
              <RefreshRoundedIcon sx={{ fontSize: 20, color: loading ? "#cbd5e1" : "#6366f1" }} />
            </IconButton>
          </Tooltip>
        </Box>

        {/* Search + filters */}
        <Box sx={{ display: "flex", gap: 2, mb: 3, flexWrap: "wrap", alignItems: "center" }}>
          <TextField
            placeholder="Search by name, email, or role…"
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
            size="small"
            sx={{
              flex: 1, minWidth: 240,
              "& .MuiOutlinedInput-root": {
                borderRadius: "12px", background: "#fff",
                "& fieldset": { borderColor: "#e2e8f0" },
                "&:hover fieldset": { borderColor: "#6366f1" },
                "&.Mui-focused fieldset": { borderColor: "#6366f1" },
              },
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchRoundedIcon sx={{ color: "#94a3b8", fontSize: 20 }} />
                </InputAdornment>
              ),
            }}
          />
          {!loading && (
            <Box sx={{ display: "flex", gap: 1 }}>
              {[
                { label: "All",     count: users.length },
                { label: "Admins",  count: users.filter(u => u.role === "ADMIN").length },
                { label: "Blocked", count: users.filter(u => u.status === "BLOCKED").length },
              ].map(tag => (
                <Chip key={tag.label} label={`${tag.label} · ${tag.count}`} size="small"
                  sx={{ fontWeight: 600, fontSize: "0.75rem",
                    background: "rgba(99,102,241,0.08)", color: "#6366f1",
                    border: "1px solid rgba(99,102,241,0.2)" }} />
              ))}
            </Box>
          )}
        </Box>

        {/* Table */}
        <Paper elevation={0} sx={{ borderRadius: "16px", border: "1px solid #e8ecf4", overflow: "hidden" }}>
          {error ? (
            <Box sx={{ p: 5, textAlign: "center" }}>
              <PeopleRoundedIcon sx={{ fontSize: 48, color: "#e2e8f0", mb: 2 }} />
              <Typography sx={{ fontWeight: 600, color: "#dc2626" }}>Failed to load users</Typography>
              <Typography sx={{ fontSize: "0.875rem", color: "#94a3b8", mt: 0.5 }}>{error}</Typography>
              <Button onClick={fetchUsers} sx={{ mt: 2, textTransform: "none", color: "#6366f1" }}>Try again</Button>
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead sx={{ background: "#f8fafc" }}>
                  <TableRow>
                    <TableCell sx={COL_SX}>User</TableCell>
                    <TableCell sx={COL_SX}>Email</TableCell>
                    <TableCell sx={COL_SX}>Role</TableCell>
                    <TableCell sx={COL_SX}>Status</TableCell>
                    <TableCell sx={{ ...COL_SX, textAlign: "right" }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading
                    ? Array.from({ length: 6 }).map((_, i) => <TableRowSkeleton key={i} />)
                    : paginated.length === 0
                    ? (
                      <TableRow>
                        <TableCell colSpan={5} sx={{ py: 8, textAlign: "center" }}>
                          <PeopleRoundedIcon sx={{ fontSize: 40, color: "#e2e8f0", mb: 1.5, display: "block", mx: "auto" }} />
                          <Typography sx={{ color: "#94a3b8", fontWeight: 600 }}>
                            {search ? "No users match your search" : "No users found"}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )
                    : paginated.map((u, idx) => (
                      <TableRow key={u.userId ?? idx}
                        sx={{ "&:hover": { background: "#fafbff" }, "&:last-child td": { borderBottom: "none" }, transition: "background 0.12s" }}>
                        <TableCell sx={{ py: 1.5 }}>
                          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                            <Avatar sx={{ width: 36, height: 36, fontSize: "0.8rem", fontWeight: 700,
                              background: avatarColor(u.email ?? u.fullName) }}>
                              {initials(u.fullName, u.email)}
                            </Avatar>
                            <Box>
                              <Typography sx={{ fontWeight: 600, fontSize: "0.875rem", color: "#0f172a" }}>
                                {u.fullName ?? "—"}
                              </Typography>
                              <Typography sx={{ fontSize: "0.75rem", color: "#94a3b8" }}>ID #{u.userId}</Typography>
                            </Box>
                          </Box>
                        </TableCell>
                        <TableCell sx={{ fontSize: "0.875rem", color: "#475569" }}>{u.email ?? "—"}</TableCell>
                        <TableCell><RoleChip role={u.role} /></TableCell>
                        <TableCell><StatusChip status={u.status ?? "ACTIVE"} /></TableCell>
                        <TableCell sx={{ textAlign: "right" }}>
                          <Box sx={{ display: "flex", gap: 0.5, justifyContent: "flex-end" }}>
                            <Tooltip title="Change role">
                              <IconButton size="small" onClick={() => setRoleDialog({ open: true, user: u })}
                                sx={{ border: "1px solid #e2e8f0", borderRadius: "8px",
                                  "&:hover": { borderColor: "#6366f1", background: "rgba(99,102,241,0.06)" } }}>
                                <EditRoundedIcon sx={{ fontSize: 16, color: "#6366f1" }} />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title={u.status === "ACTIVE" ? "Block user" : "Unblock user"}>
                              <IconButton size="small" onClick={() => setStatusDialog({ open: true, user: u })}
                                sx={{ border: "1px solid #e2e8f0", borderRadius: "8px",
                                  "&:hover": {
                                    borderColor: u.status === "ACTIVE" ? "#ef4444" : "#22c55e",
                                    background: u.status === "ACTIVE" ? "rgba(239,68,68,0.06)" : "rgba(34,197,94,0.06)",
                                  } }}>
                                {u.status === "ACTIVE"
                                  ? <BlockRoundedIcon sx={{ fontSize: 16, color: "#ef4444" }} />
                                  : <CheckCircleRoundedIcon sx={{ fontSize: 16, color: "#22c55e" }} />}
                              </IconButton>
                            </Tooltip>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
          {!loading && !error && filtered.length > rowsPerPage && (
            <TablePagination
              component="div"
              count={filtered.length}
              page={page}
              onPageChange={(_, p) => setPage(p)}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0); }}
              rowsPerPageOptions={[10, 25, 50]}
              sx={{ borderTop: "1px solid #f1f5f9",
                "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows": { fontSize: "0.8rem" } }}
            />
          )}
        </Paper>
      </Box>

      <EditRoleDialog open={roleDialog.open} user={roleDialog.user}
        onClose={() => setRoleDialog({ open: false, user: null })}
        onConfirm={handleRoleConfirm} saving={saving} />
      <ToggleStatusDialog open={statusDialog.open} user={statusDialog.user}
        onClose={() => setStatusDialog({ open: false, user: null })}
        onConfirm={handleStatusConfirm} saving={saving} />

      <Snackbar open={toast.open} autoHideDuration={3500}
        onClose={() => setToast(t => ({ ...t, open: false }))}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}>
        <Alert severity={toast.severity} onClose={() => setToast(t => ({ ...t, open: false }))}
          sx={{ borderRadius: "12px", fontWeight: 600, boxShadow: "0 8px 24px rgba(0,0,0,0.12)" }}>
          {toast.message}
        </Alert>
      </Snackbar>
    </AdminLayout>
  );
}
