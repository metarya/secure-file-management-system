import { useEffect, useState } from "react";
import {
  Box, Typography, Grid, CircularProgress, Avatar,
  Chip, Paper,
} from "@mui/material";
import PeopleRoundedIcon from "@mui/icons-material/PeopleRounded";
import AdminPanelSettingsRoundedIcon from "@mui/icons-material/AdminPanelSettingsRounded";
import PersonRoundedIcon from "@mui/icons-material/PersonRounded";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";
import AdminLayout from "../../components/admin/AdminLayout";
import { getAdminStats } from "../../services/adminService";

function StatCard({ title, value, icon, gradient, trend }) {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: "16px",
        background: "#fff",
        border: "1px solid #e8ecf4",
        position: "relative",
        overflow: "hidden",
        transition: "transform 0.18s ease, box-shadow 0.18s ease",
        "&:hover": { transform: "translateY(-2px)", boxShadow: "0 8px 32px rgba(99,102,241,0.12)" },
      }}
    >
      {/* Accent blob */}
      <Box sx={{
        position: "absolute", top: -20, right: -20,
        width: 100, height: 100, borderRadius: "50%",
        background: gradient, opacity: 0.08,
      }} />

      <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <Box>
          <Typography sx={{ fontSize: "0.78rem", fontWeight: 600, color: "#94a3b8",
            textTransform: "uppercase", letterSpacing: "0.06em", mb: 1 }}>
            {title}
          </Typography>
          <Typography sx={{ fontSize: "2.4rem", fontWeight: 800, color: "#0f172a", lineHeight: 1 }}>
            {value ?? "—"}
          </Typography>
          {trend && (
            <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mt: 1 }}>
              <TrendingUpRoundedIcon sx={{ fontSize: 14, color: "#22c55e" }} />
              <Typography sx={{ fontSize: "0.75rem", color: "#22c55e", fontWeight: 600 }}>
                {trend}
              </Typography>
            </Box>
          )}
        </Box>
        <Avatar sx={{ width: 48, height: 48, background: gradient, borderRadius: "12px" }}>
          {icon}
        </Avatar>
      </Box>
    </Paper>
  );
}

function PageHeader() {
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });

  return (
    <Box sx={{ mb: 4, display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 2 }}>
      <Box>
        <Typography sx={{ fontSize: "0.8rem", fontWeight: 600, color: "#6366f1",
          textTransform: "uppercase", letterSpacing: "0.08em", mb: 0.5 }}>
          Overview
        </Typography>
        <Typography sx={{ fontSize: "1.8rem", fontWeight: 800, color: "#0f172a", lineHeight: 1.2 }}>
          Admin Dashboard
        </Typography>
        <Typography sx={{ fontSize: "0.875rem", color: "#94a3b8", mt: 0.5 }}>
          {dateStr}
        </Typography>
      </Box>
      <Chip
        label={`System Online · ${timeStr}`}
        size="small"
        sx={{
          background: "rgba(34,197,94,0.1)", color: "#16a34a", fontWeight: 600,
          border: "1px solid rgba(34,197,94,0.2)", fontSize: "0.75rem",
          "& .MuiChip-label": { px: 1.5 },
        }}
        icon={<Box sx={{ width: 6, height: 6, borderRadius: "50%", background: "#22c55e", ml: 1 }} />}
      />
    </Box>
  );
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getAdminStats()
      .then(setStats)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const CARDS = [
    {
      title: "Total Users",
      value: stats?.totalUsers,
      icon: <PeopleRoundedIcon sx={{ color: "#fff", fontSize: 22 }} />,
      gradient: "linear-gradient(135deg, #6366f1, #3b82f6)",
    },
    {
      title: "Admin Users",
      value: stats?.totalAdmins,
      icon: <AdminPanelSettingsRoundedIcon sx={{ color: "#fff", fontSize: 22 }} />,
      gradient: "linear-gradient(135deg, #f59e0b, #ef4444)",
    },
    {
      title: "Regular Users",
      value: stats?.totalRegularUsers,
      icon: <PersonRoundedIcon sx={{ color: "#fff", fontSize: 22 }} />,
      gradient: "linear-gradient(135deg, #10b981, #06b6d4)",
    },
  ];

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 3, md: 5 }, maxWidth: 1200, width: "100%" }}>
        <PageHeader />

        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", mt: 10 }}>
            <CircularProgress sx={{ color: "#6366f1" }} />
          </Box>
        ) : error ? (
          <Paper elevation={0} sx={{ p: 4, borderRadius: "16px", border: "1px solid #fecaca",
            background: "#fff5f5", textAlign: "center" }}>
            <Typography sx={{ color: "#dc2626", fontWeight: 600 }}>Failed to load stats</Typography>
            <Typography sx={{ color: "#94a3b8", fontSize: "0.875rem", mt: 0.5 }}>{error}</Typography>
          </Paper>
        ) : (
          <>
            <Grid container spacing={3}>
              {CARDS.map(card => (
                <Grid item xs={12} sm={6} md={4} key={card.title}>
                  <StatCard {...card} />
                </Grid>
              ))}
            </Grid>

            {/* Placeholder for future widgets */}
            <Box sx={{ mt: 4 }}>
              <Paper elevation={0} sx={{
                p: 4, borderRadius: "16px", border: "1px dashed #cbd5e1",
                background: "rgba(99,102,241,0.02)", textAlign: "center",
              }}>
                <Typography sx={{ color: "#cbd5e1", fontWeight: 600, fontSize: "0.875rem" }}>
                  System Health · Analytics · Audit Log — coming soon
                </Typography>
              </Paper>
            </Box>
          </>
        )}
      </Box>
    </AdminLayout>
  );
}
