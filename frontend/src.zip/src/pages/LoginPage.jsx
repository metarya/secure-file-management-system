import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { loadStoredUser, homeRouteForUser } from "../utils/Auth";
import {
  Box, Paper, Typography, TextField, Button, Alert, Stack, Container, InputAdornment, IconButton, CircularProgress,
} from "@mui/material";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080/api";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const stored = loadStoredUser();
    if (stored?.userId && stored?.token) {
      navigate(homeRouteForUser(stored), { replace: true });
    }
  }, []);

  async function loginUser() {
    if (!email.trim() || !password) { setMessage("Please enter your email and password."); return; }
    setLoading(true);
    setMessage("");
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (response.ok && data.userId) {
        localStorage.setItem("sfmsUser", JSON.stringify(data));
        localStorage.setItem("sfms_user", JSON.stringify(data));
        const stored = loadStoredUser();
        navigate(homeRouteForUser(stored), { replace: true });
      } else {
        setMessage(data.message || "Invalid email or password.");
      }
    } catch (error) {
      setMessage("Connection error. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) { if (e.key === "Enter") loginUser(); }

  return (
    <Box sx={{
      minHeight: "100dvh",
      background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)",
      display: "flex", alignItems: "center", justifyContent: "center", px: 2, py: 4,
      position: "relative", overflow: "hidden",
    }}>
      {/* Decorative blobs */}
      <Box sx={{ position: "absolute", top: "-10%", right: "-5%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%)", pointerEvents: "none" }} />
      <Box sx={{ position: "absolute", bottom: "-10%", left: "-5%", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%)", pointerEvents: "none" }} />

      <Container maxWidth="xs" disableGutters>
        {/* Logo */}
        <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", mb: 4 }}>
          <Box sx={{
            width: 56, height: 56, borderRadius: "16px", mb: 2,
            background: "linear-gradient(135deg, #6366f1, #3b82f6)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 8px 24px rgba(99,102,241,0.4)",
          }}>
            <FolderOpenRoundedIcon sx={{ color: "#fff", fontSize: 28 }} />
          </Box>
          <Typography sx={{ color: "#fff", fontWeight: 800, fontSize: "1.5rem", letterSpacing: "-0.02em" }}>
            FileVault
          </Typography>
          <Typography sx={{ color: "rgba(255,255,255,0.45)", fontSize: "0.85rem", mt: 0.5 }}>
            Secure file management
          </Typography>
        </Box>

        <Paper elevation={0} sx={{
          borderRadius: "24px",
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.1)",
          backdropFilter: "blur(20px)",
          p: { xs: 3, sm: 4 },
        }}>
          <Typography sx={{ color: "#fff", fontWeight: 700, fontSize: "1.4rem", mb: 0.5 }}>
            Welcome back
          </Typography>
          <Typography sx={{ color: "rgba(255,255,255,0.45)", fontSize: "0.875rem", mb: 3.5 }}>
            Sign in to your account
          </Typography>

          <Stack spacing={2.5} onKeyDown={handleKeyDown}>
            <Box>
              <Typography sx={{ color: "rgba(255,255,255,0.7)", fontSize: "0.8rem", fontWeight: 600, mb: 0.8, letterSpacing: "0.02em" }}>
                EMAIL
              </Typography>
              <TextField
                fullWidth size="small" type="email" placeholder="you@example.com"
                value={email} onChange={e => setEmail(e.target.value)}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "12px", height: 46,
                    background: "rgba(255,255,255,0.06)",
                    "& fieldset": { borderColor: "rgba(255,255,255,0.12)" },
                    "&:hover fieldset": { borderColor: "rgba(255,255,255,0.25)" },
                    "&.Mui-focused fieldset": { borderColor: "#6366f1" },
                    "& input": { color: "#fff", fontSize: "0.9rem", "&::placeholder": { color: "rgba(255,255,255,0.3)" } },
                  }
                }}
              />
            </Box>

            <Box>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 0.8 }}>
                <Typography sx={{ color: "rgba(255,255,255,0.7)", fontSize: "0.8rem", fontWeight: 600, letterSpacing: "0.02em" }}>
                  PASSWORD
                </Typography>
                <Typography
                  component={Link} to="/reset-password"
                  sx={{ color: "#818cf8", fontSize: "0.78rem", fontWeight: 600, textDecoration: "none", "&:hover": { color: "#a5b4fc" } }}
                >
                  Forgot password?
                </Typography>
              </Box>
              <TextField
                fullWidth size="small" type={showPw ? "text" : "password"} placeholder="••••••••"
                value={password} onChange={e => setPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPw(p => !p)} edge="end" sx={{ color: "rgba(255,255,255,0.3)", "&:hover": { color: "rgba(255,255,255,0.6)" } }}>
                        {showPw ? <VisibilityOff sx={{ fontSize: 18 }} /> : <Visibility sx={{ fontSize: 18 }} />}
                      </IconButton>
                    </InputAdornment>
                  )
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "12px", height: 46,
                    background: "rgba(255,255,255,0.06)",
                    "& fieldset": { borderColor: "rgba(255,255,255,0.12)" },
                    "&:hover fieldset": { borderColor: "rgba(255,255,255,0.25)" },
                    "&.Mui-focused fieldset": { borderColor: "#6366f1" },
                    "& input": { color: "#fff", fontSize: "0.9rem", "&::placeholder": { color: "rgba(255,255,255,0.3)" } },
                  }
                }}
              />
            </Box>

            {message && (
              <Alert severity="error" sx={{ borderRadius: "12px", fontSize: "0.85rem", py: 0.5 }}>
                {message}
              </Alert>
            )}

            <Button
              variant="contained" fullWidth onClick={loginUser} disabled={loading}
              sx={{
                height: 48, borderRadius: "12px", fontWeight: 700, fontSize: "0.95rem",
                background: "linear-gradient(135deg, #6366f1, #3b82f6)",
                boxShadow: "0 4px 20px rgba(99,102,241,0.4)",
                textTransform: "none", mt: 0.5,
                "&:hover": { background: "linear-gradient(135deg, #4f46e5, #2563eb)", boxShadow: "0 6px 24px rgba(99,102,241,0.5)" },
                "&.Mui-disabled": { background: "rgba(99,102,241,0.4)", color: "rgba(255,255,255,0.5)" },
              }}
            >
              {loading ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Sign in"}
            </Button>

            <Typography sx={{ textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: "0.875rem" }}>
              New here?{" "}
              <Box component={Link} to="/register"
                sx={{ color: "#818cf8", fontWeight: 700, textDecoration: "none", "&:hover": { color: "#a5b4fc" } }}>
                Create an account
              </Box>
            </Typography>
          </Stack>
        </Paper>
      </Container>
    </Box>
  );
}
