import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import authHeaders from "../utils/authHeaders";
import ShareErrorMessage from "../utils/shareErrorMessage";
import Upload from "../components/upload/Upload";
import ShareFile from "../components/share/ShareFile";
import { loadMyFiles, loadSharedWithMe, searchFiles } from "../api/fileApi";
import { loadStoredUser, logout as doLogout } from "../utils/Auth";
import {
  AppBar, Toolbar, Typography, Button, Container, Paper, Box, Alert,
  useMediaQuery, useTheme, Avatar, Tooltip, Chip,
} from "@mui/material";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";
import CloudUploadRoundedIcon from "@mui/icons-material/CloudUploadRounded";
import ShareRoundedIcon from "@mui/icons-material/ShareRounded";
import FolderRoundedIcon from "@mui/icons-material/FolderRounded";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import AdminPanelSettingsRoundedIcon from "@mui/icons-material/AdminPanelSettingsRounded";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080/api";

function initials(name, email) {
  if (name) return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  if (email) return email[0].toUpperCase();
  return "?";
}

export default function DashboardPage() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const navigate = useNavigate();

  const user = loadStoredUser();

  useEffect(() => {
    if (!user?.userId || !user?.token) navigate("/login", { replace: true });
  }, []);

  const [activeTab, setActiveTab] = useState("upload");
  const [File, setFile] = useState(null);
  const [FileName, setFileName] = useState("");
  const [FileDescription, setFileDescription] = useState("");
  const [files, setFiles] = useState([]);
  const [sharedFiles, setSharedFiles] = useState([]);
  const [notification, setNotification] = useState({ text: "", type: "info" });
  const [shareFileId, setShareFileId] = useState("");
  const [targetUserEmail, setTargetUserEmail] = useState("");
  const [permissionType, setPermissionType] = useState("VIEW");
  const [shareMessage, setShareMessage] = useState("");

  useEffect(() => {
    if (!notification.text) return;
    const t = setTimeout(() => setNotification({ text: "", type: "info" }), 4000);
    return () => clearTimeout(t);
  }, [notification.text]);

  useEffect(() => {
    fetchMyFilesData();
    fetchSharedFilesData();
  }, []);

  async function fetchMyFilesData() {
    try {
      const result = await loadMyFiles(user);
      if (result.ok) setFiles(result.data);
    } catch {}
  }

  async function fetchSharedFilesData() {
    try {
      const result = await loadSharedWithMe(user);
      if (result.ok) setSharedFiles(result.data);
    } catch {}
  }

  async function uploadFile() {
    if (!File) { setNotification({ text: "Please select a .txt file.", type: "error" }); return; }
    const enteredFileName = FileName.trim();
    if (!enteredFileName) { setNotification({ text: "Please enter a file name.", type: "error" }); return; }
    const safeFileName = enteredFileName.replace(/[\\/:*?"<>|]/g, "-").replace(/\s+/g, " ").trim();
    const finalFileName = safeFileName.toLowerCase().endsWith(".txt") ? safeFileName : `${safeFileName}.txt`;
    const renamedFile = new window.File([File], finalFileName, { type: File.type || "text/plain", lastModified: File.lastModified });
    const formData = new FormData();
    formData.append("file", renamedFile);
    formData.append("ownerId", user.userId);
    formData.append("description", FileDescription.trim());
    try {
      const response = await fetch(`${API_BASE_URL}/files/upload`, {
        method: "POST", headers: authHeaders(user?.token), body: formData,
      });
      const text = await response.text();
      if (response.ok) {
        setNotification({ text: `Uploaded: ${finalFileName}`, type: "success" });
        setFile(null); setFileName(""); setFileDescription("");
        const fi = document.querySelector('input[type="file"]');
        if (fi) fi.value = "";
        fetchMyFilesData();
      } else {
        setNotification({ text: text || "Upload failed.", type: "error" });
      }
    } catch (error) {
      setNotification({ text: "Upload failed: " + error.message, type: "error" });
    }
  }

  async function shareFileAccess() {
    if (!targetUserEmail.trim()) { setShareMessage("Please enter target user email."); return; }
    try {
      const response = await fetch(`${API_BASE_URL}/files/share`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders(user?.token) },
        body: JSON.stringify({ fileId: Number(shareFileId), targetUserEmail: targetUserEmail.trim(), permissionType }),
      });
      const data = await response.json().catch(() => null);
      if (response.ok) {
        setShareMessage(data?.message || "File shared successfully.");
        setNotification({ text: "Sharing updated.", type: "success" });
        setShareFileId(""); setTargetUserEmail(""); fetchMyFilesData();
      } else {
        setShareMessage(ShareErrorMessage(data?.message || data?.error, response.status));
      }
    } catch (error) {
      setShareMessage(ShareErrorMessage(error.message));
    }
  }

  function handleLogout() {
    doLogout();
    navigate("/login", { replace: true });
  }

  if (!user) return null;

  const isAdmin = user.role === "ADMIN";

  return (
    <Box sx={{ backgroundColor: "#f1f5f9", minHeight: "100dvh" }}>
      {/* Navbar */}
      <AppBar position="sticky" elevation={0} sx={{
        background: "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}>
        <Toolbar sx={{ px: { xs: 2, md: 4 }, minHeight: { xs: 64, md: 72 }, gap: 2 }}>
          {/* Brand */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, flexGrow: 1 }}>
            <Box sx={{
              width: 36, height: 36, borderRadius: "10px",
              background: "linear-gradient(135deg, #6366f1, #3b82f6)",
              display: "flex", alignItems: "center", justifyContent: "center",
              flexShrink: 0,
            }}>
              <FolderOpenRoundedIcon sx={{ color: "#fff", fontSize: 20 }} />
            </Box>
            <Typography sx={{ fontWeight: 800, fontSize: { xs: "1.05rem", md: "1.2rem" }, color: "#fff", letterSpacing: "-0.02em" }}>
              FileVault
            </Typography>
          </Box>

          {/* Nav actions */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            {isAdmin && (
              <Tooltip title="Admin Panel">
                <Button
                  component={Link} to="/admin/dashboard"
                  startIcon={!isMobile && <AdminPanelSettingsRoundedIcon />}
                  sx={{
                    color: "#fbbf24", fontWeight: 700, textTransform: "none", fontSize: "0.85rem",
                    borderRadius: "10px", px: { xs: 1.5, md: 2 },
                    border: "1px solid rgba(251,191,36,0.25)",
                    "&:hover": { background: "rgba(251,191,36,0.1)" },
                  }}
                >
                  {isMobile ? <AdminPanelSettingsRoundedIcon sx={{ fontSize: 20 }} /> : "Admin"}
                </Button>
              </Tooltip>
            )}
            <Tooltip title="My Files">
              <Button
                component={Link} to="/files"
                startIcon={!isMobile && <FolderRoundedIcon />}
                sx={{
                  color: "rgba(255,255,255,0.8)", fontWeight: 600, textTransform: "none", fontSize: "0.85rem",
                  borderRadius: "10px", px: { xs: 1.5, md: 2 },
                  "&:hover": { background: "rgba(255,255,255,0.08)", color: "#fff" },
                }}
              >
                {isMobile ? <FolderRoundedIcon sx={{ fontSize: 20 }} /> : "Files"}
              </Button>
            </Tooltip>

            {/* User avatar */}
            <Tooltip title={user.fullName || user.email || "Account"}>
              <Avatar sx={{
                width: 34, height: 34, fontSize: "0.8rem", fontWeight: 700, cursor: "default",
                background: "linear-gradient(135deg, #6366f1, #3b82f6)",
              }}>
                {initials(user.fullName, user.email)}
              </Avatar>
            </Tooltip>

            <Tooltip title="Sign out">
              <Button
                onClick={handleLogout}
                sx={{
                  minWidth: 0, color: "rgba(255,255,255,0.5)", borderRadius: "10px", px: 1,
                  "&:hover": { background: "rgba(239,68,68,0.12)", color: "#f87171" },
                }}
              >
                <LogoutRoundedIcon sx={{ fontSize: 20 }} />
              </Button>
            </Tooltip>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Content */}
      <Container maxWidth={false} sx={{ py: { xs: 3, md: 5 }, px: { xs: 2, sm: 3, md: 5 }, display: "flex", flexDirection: "column", alignItems: "center" }}>
        {/* Page heading */}
        <Box sx={{ width: "100%", maxWidth: 560, mb: 3 }}>
          <Typography sx={{ fontWeight: 800, fontSize: { xs: "1.5rem", md: "1.8rem" }, color: "#0f172a", letterSpacing: "-0.02em" }}>
            Dashboard
          </Typography>
          <Typography sx={{ color: "#64748b", fontSize: "0.9rem", mt: 0.5 }}>
            Upload files or share access with your team
          </Typography>
        </Box>

        {/* Notification */}
        {notification.text && (
          <Box sx={{ width: "100%", maxWidth: 560, mb: 2 }}>
            <Alert severity={notification.type} sx={{ borderRadius: "12px" }}>{notification.text}</Alert>
          </Box>
        )}

        {/* Card */}
        <Paper elevation={0} sx={{
          width: "100%", maxWidth: 560, borderRadius: "20px",
          border: "1px solid #e2e8f0", boxShadow: "0 4px 24px rgba(15,23,42,0.06)",
          overflow: "hidden", background: "#fff",
        }}>
          {/* Tab strip */}
          <Box sx={{ display: "flex", gap: 0.5, p: 1.5, background: "#f8fafc", borderBottom: "1px solid #f1f5f9" }}>
            {[
              { id: "upload", label: "Upload", icon: <CloudUploadRoundedIcon sx={{ fontSize: 16 }} /> },
              { id: "share", label: "Share", icon: <ShareRoundedIcon sx={{ fontSize: 16 }} /> },
            ].map(tab => {
              const active = activeTab === tab.id;
              return (
                <Button key={tab.id} onClick={() => setActiveTab(tab.id)} disableElevation
                  startIcon={tab.icon}
                  sx={{
                    flex: 1, textTransform: "none", fontWeight: 700, fontSize: "0.875rem",
                    borderRadius: "10px", py: 1, gap: 0.5,
                    background: active ? "#fff" : "transparent",
                    color: active ? "#6366f1" : "#94a3b8",
                    boxShadow: active ? "0 1px 8px rgba(0,0,0,0.08)" : "none",
                    "&:hover": { background: active ? "#fff" : "#f1f5f9", color: active ? "#6366f1" : "#64748b" },
                  }}
                >
                  {tab.label}
                </Button>
              );
            })}
          </Box>

          {/* Panel */}
          <Box sx={{ p: { xs: 3, sm: 4 } }}>
            {activeTab === "upload" ? (
              <Upload
                FileName={FileName} setFileName={setFileName}
                FileDescription={FileDescription} setFileDescription={setFileDescription}
                setFile={setFile} uploadFile={uploadFile}
              />
            ) : (
              <ShareFile
                files={[...files, ...sharedFiles]}
                shareFileId={shareFileId} setShareFileId={setShareFileId}
                targetUserEmail={targetUserEmail} setTargetUserEmail={setTargetUserEmail}
                permissionType={permissionType} setPermissionType={setPermissionType}
                shareFileAccess={shareFileAccess} shareMessage={shareMessage}
              />
            )}
          </Box>
        </Paper>

        {/* Stats row */}
        <Box sx={{ display: "flex", gap: 2, mt: 3, width: "100%", maxWidth: 560, flexWrap: "wrap" }}>
          {[
            { label: "My Files", value: files.length, color: "#6366f1" },
            { label: "Shared with me", value: sharedFiles.length, color: "#10b981" },
          ].map(s => (
            <Box key={s.label} sx={{
              flex: 1, minWidth: 120, p: 2, borderRadius: "14px",
              background: "#fff", border: "1px solid #e2e8f0",
              display: "flex", flexDirection: "column", gap: 0.5,
            }}>
              <Typography sx={{ fontSize: "1.5rem", fontWeight: 800, color: s.color, lineHeight: 1 }}>{s.value}</Typography>
              <Typography sx={{ fontSize: "0.78rem", color: "#94a3b8", fontWeight: 600 }}>{s.label}</Typography>
            </Box>
          ))}
        </Box>
      </Container>
    </Box>
  );
}
