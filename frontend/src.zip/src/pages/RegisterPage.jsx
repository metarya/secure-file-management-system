import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  Box, Paper, Typography, TextField, Button, Alert, Stack, Container, InputAdornment, IconButton, CircularProgress,
} from "@mui/material";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080/api";

export default function RegisterPage() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [message, setMessage] = useState({ text: "", type: "error" });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function registerUser() {
    if (!fullName.trim() || !email.trim() || !password) {
      setMessage({ text: "Please fill in all fields.", type: "error" }); return;
    }
    setLoading(true);
    setMessage({ text: "", type: "error" });
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, password }),
      });
      const text = await response.text();
      if (response.ok && text.toLowerCase().includes("success")) {
        setMessage({ text: "Account created! Redirecting to login…", type: "success" });
        setTimeout(() => navigate("/login"), 1200);
      } else {
        setMessage({ text: text || "Registration failed.", type: "error" });
      }
    } catch (error) {
      setMessage({ text: "Connection error. Please try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  }

  const inputSx = {
    "& .MuiOutlinedInput-root": {
      borderRadius: "12px", height: 46,
      background: "rgba(255,255,255,0.06)",
      "& fieldset": { borderColor: "rgba(255,255,255,0.12)" },
      "&:hover fieldset": { borderColor: "rgba(255,255,255,0.25)" },
      "&.Mui-focused fieldset": { borderColor: "#6366f1" },
      "& input": { color: "#fff", fontSize: "0.9rem", "&::placeholder": { color: "rgba(255,255,255,0.3)" } },
    }
  };

  return (
    <Box sx={{
      minHeight: "100dvh",
      background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)",
      display: "flex", alignItems: "center", justifyContent: "center", px: 2, py: 4,
      position: "relative", overflow: "hidden",
    }}>
      <Box sx={{ position: "absolute", top: "-10%", right: "-5%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%)", pointerEvents: "none" }} />
      <Box sx={{ position: "absolute", bottom: "-10%", left: "-5%", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%)", pointerEvents: "none" }} />

      <Container maxWidth="xs" disableGutters>
        <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", mb: 4 }}>
          <Box sx={{
            width: 56, height: 56, borderRadius: "16px", mb: 2,
            background: "linear-gradient(135deg, #6366f1, #3b82f6)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 8px 24px rgba(99,102,241,0.4)",
          }}>
            <FolderOpenRoundedIcon sx={{ color: "#fff", fontSize: 28 }} />
          </Box>
          <Typography sx={{ color: "#fff", fontWeight: 800, fontSize: "1.5rem", letterSpacing: "-0.02em" }}>FileVault</Typography>
          <Typography sx={{ color: "rgba(255,255,255,0.45)", fontSize: "0.85rem", mt: 0.5 }}>Secure file management</Typography>
        </Box>

        <Paper elevation={0} sx={{
          borderRadius: "24px",
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.1)",
          backdropFilter: "blur(20px)",
          p: { xs: 3, sm: 4 },
        }}>
          <Typography sx={{ color: "#fff", fontWeight: 700, fontSize: "1.4rem", mb: 0.5 }}>Create account</Typography>
          <Typography sx={{ color: "rgba(255,255,255,0.45)", fontSize: "0.875rem", mb: 3.5 }}>Join FileVault today</Typography>

          <Stack spacing={2.5}>
            {[
              { label: "FULL NAME", value: fullName, setter: setFullName, placeholder: "John Doe", type: "text" },
              { label: "EMAIL", value: email, setter: setEmail, placeholder: "you@example.com", type: "email" },
            ].map(({ label, value, setter, placeholder, type }) => (
              <Box key={label}>
                <Typography sx={{ color: "rgba(255,255,255,0.7)", fontSize: "0.8rem", fontWeight: 600, mb: 0.8, letterSpacing: "0.02em" }}>{label}</Typography>
                <TextField fullWidth size="small" type={type} placeholder={placeholder} value={value} onChange={e => setter(e.target.value)} sx={inputSx} />
              </Box>
            ))}

            <Box>
              <Typography sx={{ color: "rgba(255,255,255,0.7)", fontSize: "0.8rem", fontWeight: 600, mb: 0.8, letterSpacing: "0.02em" }}>PASSWORD</Typography>
              <TextField
                fullWidth size="small" type={showPw ? "text" : "password"} placeholder="Min. 8 characters"
                value={password} onChange={e => setPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPw(p => !p)} edge="end" sx={{ color: "rgba(255,255,255,0.3)", "&:hover": { color: "rgba(255,255,255,0.6)" } }}>
                        {showPw ? <VisibilityOff sx={{ fontSize: 18 }} /> : <Visibility sx={{ fontSize: 18 }} />}
                      </IconButton>
                    </InputAdornment>
                  )
                }}
                sx={inputSx}
              />
            </Box>

            {message.text && (
              <Alert severity={message.type} sx={{ borderRadius: "12px", fontSize: "0.85rem", py: 0.5 }}>
                {message.text}
              </Alert>
            )}

            <Button
              variant="contained" fullWidth onClick={registerUser} disabled={loading}
              sx={{
                height: 48, borderRadius: "12px", fontWeight: 700, fontSize: "0.95rem",
                background: "linear-gradient(135deg, #6366f1, #3b82f6)",
                boxShadow: "0 4px 20px rgba(99,102,241,0.4)",
                textTransform: "none", mt: 0.5,
                "&:hover": { background: "linear-gradient(135deg, #4f46e5, #2563eb)" },
                "&.Mui-disabled": { background: "rgba(99,102,241,0.4)", color: "rgba(255,255,255,0.5)" },
              }}
            >
              {loading ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Create account"}
            </Button>

            <Typography sx={{ textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: "0.875rem" }}>
              Already have an account?{" "}
              <Box component={Link} to="/login"
                sx={{ color: "#818cf8", fontWeight: 700, textDecoration: "none", "&:hover": { color: "#a5b4fc" } }}>
                Sign in
              </Box>
            </Typography>
          </Stack>
        </Paper>
      </Container>
    </Box>
  );
}
