// src/routes/AdminRoute.jsx   (sits alongside AppRoutes.jsx)
import { Navigate } from "react-router-dom";
import { loadStoredUser, isAuthenticated, isAdmin } from "../utils/Auth";

// Gate for admin-only routes. Order matters:
//   not logged in        → /login
//   logged in, not admin → /dashboard
//
// Usage:
//   <Route
//     path="/admin"
//     element={
//       <AdminRoute>
//         <AdminDashboardPage />
//       </AdminRoute>
//     }
//   />
export default function AdminRoute({ children }) {
  const user = loadStoredUser();

  if (!isAuthenticated(user)) {
    return <Navigate to="/login" replace />;
  }
  if (!isAdmin(user)) {
    // Authenticated but not an admin → bounce to the normal dashboard.
    return <Navigate to="/dashboard" replace />;
  }
  return children;
}