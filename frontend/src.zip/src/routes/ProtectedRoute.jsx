// src/components/ProtectedRoute.jsx
import { Navigate, useLocation } from "react-router-dom";
import { loadStoredUser, isAuthenticated } from "../utils/Auth";

// Gate for any route that requires a logged-in user.
//
// Usage:
//   <Route
//     path="/dashboard"
//     element={
//       <ProtectedRoute>
//         <DashboardPage />
//       </ProtectedRoute>
//     }
//   />
export default function ProtectedRoute({ children }) {
  const location = useLocation();
  const user = loadStoredUser();

  if (!isAuthenticated(user)) {
    // Not logged in → go to login, remembering where they were headed so
    // LoginPage can send them back after a successful sign-in (optional).
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return children;
}