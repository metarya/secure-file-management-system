// This file is kept for backward compatibility.
// The app entry point is main.jsx → AppRoutes.jsx.
// DashboardPage is at src/pages/DashboardPage.jsx
export { default } from "./pages/DashboardPage";
