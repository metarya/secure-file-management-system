// src/utils/Auth.js
// Single source of truth for reading the logged-in user (including role) from localStorage.

const STORAGE_KEYS = [
  "sfmsUser", "sfms_user", "user", "loggedInUser",
  "currentUser", "authUser", "secureFileUser", "fileManagementUser",
];

function resolveRole(parsed) {
  const raw =
    parsed.role ??
    parsed.userRole ??
    parsed.user?.role ??
    (Array.isArray(parsed.roles) ? parsed.roles[0] : parsed.roles) ??
    (Array.isArray(parsed.authorities)
      ? (typeof parsed.authorities[0] === "string"
          ? parsed.authorities[0]
          : parsed.authorities[0]?.authority)
      : undefined) ??
    parsed.user?.roles?.[0] ??
    "";

  return String(raw || "").toUpperCase().replace(/^ROLE_/, "");
}

export function loadStoredUser() {
  for (const key of STORAGE_KEYS) {
    const saved = localStorage.getItem(key);
    if (!saved) continue;
    try {
      const parsed = JSON.parse(saved);
      return {
        ...parsed,
        userId:   parsed.userId   ?? parsed.id   ?? parsed.user?.userId ?? parsed.user?.id,
        email:    parsed.email    ?? parsed.user?.email,
        fullName: parsed.fullName ?? parsed.name ?? parsed.user?.fullName,
        token:    parsed.token    ?? parsed.jwt  ?? parsed.accessToken  ?? parsed.user?.token,
        role:     resolveRole(parsed),
      };
    } catch {
      continue;
    }
  }
  return null;
}

export function isAuthenticated(user) {
  return Boolean(user?.userId && user?.token);
}

export function isAdmin(user) {
  return user?.role === "ADMIN";
}

export function logout() {
  STORAGE_KEYS.forEach(k => localStorage.removeItem(k));
}

// Where a freshly-authenticated user should land.
export function homeRouteForUser(user) {
  return isAdmin(user) ? "/admin/dashboard" : "/dashboard";
}
